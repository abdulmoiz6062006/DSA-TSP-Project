#ifndef VISUALIZER_H
#define VISUALIZER_H

#include "Graph.h"

class Visualizer
{
public:

    static void drawGraph(Graph &g);
};

#endif