// ============================
// Graph.h
// ============================

#ifndef GRAPH_H
#define GRAPH_H

#include<iostream>
#include<fstream>
#include<string>

using namespace std;

class Graph
{
public:

    struct Node
    {
        int city;
        int weight;
        Node* next;
    };

    int vertices;

    string cityNames[20];

    int adjMatrix[20][20];

    Node* adjList[20];

    Graph();

    void loadFromFile(string filename);

    void displayMatrix();

    void displayList();

    bool isDisconnected();
};

#endif