// ============================
// main.cpp
// ============================

#include<iostream>

#include "Graph.h"
#include "Algorithms.h"
#include "Visualizer.h"

using namespace std;

int main()
{
    Graph g;

    g.loadFromFile("cities8.txt");

    if(g.isDisconnected())
    {
        cout << "Disconnected Graph\n";

        return 0;
    }

    int choice;

    do
    {
        cout
        << "\n================================";

        cout
        << "\n1. Display Matrix";

        cout
        << "\n2. Display Linked List";

        cout
        << "\n3. Visualize Graph";

        cout
        << "\n4. Brute Force Static";

        cout
        << "\n5. Brute Force Dynamic";

        cout
        << "\n6. Greedy Static";

        cout
        << "\n7. Greedy Dynamic";

        cout
        << "\n8. Custom Algorithm";

        cout
        << "\n9. Run All";

        cout
        << "\n0. Exit";

        cout
        << "\n\nEnter Choice: ";

        cin >> choice;

        switch(choice)
        {
            case 1:

                g.displayMatrix();

                break;

            case 2:

                g.displayList();

                break;

            case 3:

                Visualizer::drawGraph(g);

                break;

            case 4:

                Algorithms::bruteForceMatrix(g);

                break;

            case 5:

                Algorithms::bruteForceList(g);

                break;

            case 6:

                Algorithms::greedyMatrix(g);

                break;

            case 7:

                Algorithms::greedyList(g);

                break;

            case 8:

                Algorithms::customAlgorithm(g);

                break;

            case 9:

                Algorithms::bruteForceMatrix(g);

                Algorithms::bruteForceList(g);

                Algorithms::greedyMatrix(g);

                Algorithms::greedyList(g);

                Algorithms::customAlgorithm(g);

                Algorithms::performanceReport();

                break;

            case 0:

                cout << "\nProgram Ended\n";

                break;

            default:

                cout << "\nInvalid Choice\n";
        }

    } while(choice != 0);

    return 0;
}