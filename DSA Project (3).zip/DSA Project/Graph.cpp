// ============================
// Graph.cpp
// ============================

#include "Graph.h"

Graph::Graph()
{
    vertices = 0;

    for(int i = 0; i < 20; i++)
    {
        adjList[i] = NULL;
    }
}

void Graph::loadFromFile(string filename)
{
    ifstream file(filename.c_str());

    if(!file)
    {
        cout << "File Error\n";
        return;
    }

    file >> vertices;

    for(int i = 0; i < vertices; i++)
    {
        file >> cityNames[i];
    }

    for(int i = 0; i < vertices; i++)
    {
        for(int j = 0; j < vertices; j++)
        {
            file >> adjMatrix[i][j];
        }
    }

    for(int i = 0; i < vertices; i++)
    {
        adjList[i] = NULL;

        for(int j = 0; j < vertices; j++)
        {
            if(adjMatrix[i][j] != 0)
            {
                Node* newNode = new Node;

                newNode->city = j;
                newNode->weight = adjMatrix[i][j];
                newNode->next = NULL;

                if(adjList[i] == NULL)
                {
                    adjList[i] = newNode;
                }
                else
                {
                    Node* temp = adjList[i];

                    while(temp->next != NULL)
                    {
                        temp = temp->next;
                    }

                    temp->next = newNode;
                }
            }
        }
    }

    file.close();
}

void Graph::displayMatrix()
{
    cout << "\n===== Adjacency Matrix =====\n\n";

    cout << "\t";

    for(int i = 0; i < vertices; i++)
    {
        cout << cityNames[i] << "\t";
    }

    cout << endl;

    for(int i = 0; i < vertices; i++)
    {
        cout << cityNames[i] << "\t";

        for(int j = 0; j < vertices; j++)
        {
            cout << adjMatrix[i][j] << "\t";
        }

        cout << endl;
    }
}

void Graph::displayList()
{
    cout << "\n===== Adjacency Linked List =====\n\n";

    for(int i = 0; i < vertices; i++)
    {
        cout << cityNames[i] << " -> ";

        Node* temp = adjList[i];

        while(temp != NULL)
        {
            cout << cityNames[temp->city]
                 << "("
                 << temp->weight
                 << ") ";

            temp = temp->next;
        }

        cout << endl;
    }
}

bool Graph::isDisconnected()
{
    for(int i = 0; i < vertices; i++)
    {
        int connected = 0;

        for(int j = 0; j < vertices; j++)
        {
            if(adjMatrix[i][j] != 0)
            {
                connected = 1;
            }
        }

        if(connected == 0)
        {
            return true;
        }
    }

    return false;
}