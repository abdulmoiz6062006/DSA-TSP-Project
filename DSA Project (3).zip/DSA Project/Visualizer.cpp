// ============================
// Visualizer.cpp
// ============================

#include "Visualizer.h"

void Visualizer::drawGraph(Graph &g)
{
    cout << "\n===== Graph Visualization =====\n\n";

    for(int i = 0; i < g.vertices; i++)
    {
        cout << g.cityNames[i] << " -> ";

        Graph::Node* temp =
        g.adjList[i];

        while(temp != NULL)
        {
            cout
            << g.cityNames[temp->city]
            << "("
            << temp->weight
            << ") ";

            temp = temp->next;
        }

        cout << endl;
    }
}