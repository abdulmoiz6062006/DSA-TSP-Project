// ============================
// Algorithms.cpp
// ============================

#include "Algorithms.h"

#include<iostream>
#include<ctime>
#include<iomanip>

using namespace std;

double bruteForceTime = 0;

double bruteForceDynamicTime = 0;

double greedyMatrixTime = 0;

double greedyListTime = 0;

double customTime = 0;

int minimumCost = 99999;

int bestPath[20];

void copyPath(int path[], int size)
{
    for(int i = 0; i < size; i++)
    {
        bestPath[i] = path[i];
    }
}

void bruteForceRecursive(
    Graph &g,
    int path[],
    int visited[],
    int level,
    int cost
)
{
    if(level == g.vertices)
    {
        if(g.adjMatrix[path[level - 1]][0] != 0)
        {
            cost =
            cost +
            g.adjMatrix[path[level - 1]][0];

            if(cost < minimumCost)
            {
                minimumCost = cost;

                copyPath(path, g.vertices);
            }
        }

        return;
    }

    for(int i = 1; i < g.vertices; i++)
    {
        if(visited[i] == 0 &&
           g.adjMatrix[path[level - 1]][i] != 0)
        {
            visited[i] = 1;

            path[level] = i;

            bruteForceRecursive(
                g,
                path,
                visited,
                level + 1,
                cost +
                g.adjMatrix[path[level - 1]][i]
            );

            visited[i] = 0;
        }
    }
}

void Algorithms::bruteForceMatrix(Graph &g)
{
    clock_t start, end;

    start = clock();

    int path[20];

    int visited[20];

    for(int i = 0; i < 20; i++)
    {
        visited[i] = 0;
    }

    minimumCost = 99999;

    path[0] = 0;

    visited[0] = 1;

    bruteForceRecursive(
        g,
        path,
        visited,
        1,
        0
    );

    end = clock();

    bruteForceTime =
    ((double)(end - start) * 1000)
    /
    CLOCKS_PER_SEC;

    cout << fixed << setprecision(6);

    cout << "\n===== Brute Force =====\n";

    cout << "Route: ";

    for(int i = 0; i < g.vertices; i++)
    {
        cout
        << g.cityNames[bestPath[i]]
        << " -> ";
    }

    cout << g.cityNames[0];

    cout << "\nCost: "
         << minimumCost;

    cout << "\nExecution Time: "
         << bruteForceTime
         << " ms";

    cout << "\nComplexity: O(n!)\n";
}

void bruteForceListRecursive(
    Graph &g,
    int path[],
    int visited[],
    int level,
    int cost
)
{
    if(level == g.vertices)
    {
        if(g.adjMatrix[path[level - 1]][0] != 0)
        {
            cost =
            cost +
            g.adjMatrix[path[level - 1]][0];

            if(cost < minimumCost)
            {
                minimumCost = cost;

                copyPath(path, g.vertices);
            }
        }

        return;
    }

    Graph::Node* temp =
    g.adjList[path[level - 1]];

    while(temp != NULL)
    {
        int city = temp->city;

        if(visited[city] == 0)
        {
            visited[city] = 1;

            path[level] = city;

            bruteForceListRecursive(
                g,
                path,
                visited,
                level + 1,
                cost + temp->weight
            );

            visited[city] = 0;
        }

        temp = temp->next;
    }
}

void Algorithms::bruteForceList(Graph &g)
{
    clock_t start, end;

    start = clock();

    int path[20];

    int visited[20];

    for(int i = 0; i < 20; i++)
    {
        visited[i] = 0;
    }

    minimumCost = 99999;

    path[0] = 0;

    visited[0] = 1;

    bruteForceListRecursive(
        g,
        path,
        visited,
        1,
        0
    );

    end = clock();

    bruteForceDynamicTime =
    ((double)(end - start) * 1000)
    /
    CLOCKS_PER_SEC;

    cout << fixed << setprecision(6);

    cout << "\n===== Brute Force (Dynamic) =====\n";

    cout << "Route: ";

    for(int i = 0; i < g.vertices; i++)
    {
        cout
        << g.cityNames[bestPath[i]]
        << " -> ";
    }

    cout << g.cityNames[0];

    cout << "\nCost: "
         << minimumCost;

    cout << "\nExecution Time: "
         << bruteForceDynamicTime
         << " ms";

    cout << "\nComplexity: O(n!)\n";
}

void Algorithms::greedyMatrix(Graph &g)
{
    clock_t start, end;

    start = clock();

    int visited[20];

    int route[20];

    for(int i = 0; i < 20; i++)
    {
        visited[i] = 0;
    }

    int current = 0;

    int totalCost = 0;

    visited[0] = 1;

    route[0] = 0;

    for(int count = 1;
        count < g.vertices;
        count++)
    {
        int min = 99999;

        int next = -1;

        for(int i = 0;
            i < g.vertices;
            i++)
        {
            if(
                visited[i] == 0 &&
                g.adjMatrix[current][i] != 0
            )
            {
                if(g.adjMatrix[current][i] < min)
                {
                    min =
                    g.adjMatrix[current][i];

                    next = i;
                }
            }
        }

        route[count] = next;

        visited[next] = 1;

        totalCost = totalCost + min;

        current = next;
    }

    totalCost =
    totalCost +
    g.adjMatrix[current][0];

    end = clock();

    greedyMatrixTime =
    ((double)(end - start) * 1000)
    /
    CLOCKS_PER_SEC;

    cout << fixed << setprecision(6);

    cout
    << "\n===== Greedy (Static Representation) =====\n";

    cout << "Route: ";

    for(int i = 0; i < g.vertices; i++)
    {
        cout
        << g.cityNames[route[i]]
        << " -> ";
    }

    cout << g.cityNames[0];

    cout << "\nCost: "
         << totalCost;

    cout << "\nExecution Time: "
         << greedyMatrixTime
         << " ms";

    cout << "\nComplexity: O(n^2)\n";
}

void Algorithms::greedyList(Graph &g)
{
    clock_t start, end;

    start = clock();

    int visited[20];

    int route[20];

    for(int i = 0; i < 20; i++)
    {
        visited[i] = 0;
    }

    int current = 0;

    int totalCost = 0;

    visited[0] = 1;

    route[0] = 0;

    for(int count = 1;
        count < g.vertices;
        count++)
    {
        int min = 99999;

        int next = -1;

        Graph::Node* temp =
        g.adjList[current];

        while(temp != NULL)
        {
            if(
                visited[temp->city] == 0
            )
            {
                if(temp->weight < min)
                {
                    min = temp->weight;

                    next = temp->city;
                }
            }

            temp = temp->next;
        }

        route[count] = next;

        visited[next] = 1;

        totalCost = totalCost + min;

        current = next;
    }

    totalCost =
    totalCost +
    g.adjMatrix[current][0];

    end = clock();

    greedyListTime =
    ((double)(end - start) * 1000)
    /
    CLOCKS_PER_SEC;

    cout << fixed << setprecision(6);

    cout
    << "\n===== Greedy (Dynamic Representation) =====\n";

    cout << "Route: ";

    for(int i = 0; i < g.vertices; i++)
    {
        cout
        << g.cityNames[route[i]]
        << " -> ";
    }

    cout << g.cityNames[0];

    cout << "\nCost: "
         << totalCost;

    cout << "\nExecution Time: "
         << greedyListTime
         << " ms";

    cout << "\nComplexity: O(V + E)\n";
}

void Algorithms::customAlgorithm(Graph &g)
{
    clock_t start, end;

    start = clock();

    int visited[20];

    int route[20];

    for(int i = 0; i < 20; i++)
    {
        visited[i] = 0;
    }

    int current = 0;

    int totalCost = 0;

    visited[0] = 1;

    route[0] = 0;

    for(int count = 1;
        count < g.vertices;
        count++)
    {
        int shortest = 99999;

        int secondShortest = 99999;

        int bestCity = -1;

        int secondCity = -1;

        for(int i = 0;
            i < g.vertices;
            i++)
        {
            if(
                visited[i] == 0 &&
                g.adjMatrix[current][i] != 0
            )
            {
                int weight =
                g.adjMatrix[current][i];

                if(weight < shortest)
                {
                    secondShortest = shortest;

                    secondCity = bestCity;

                    shortest = weight;

                    bestCity = i;
                }
                else if(weight < secondShortest)
                {
                    secondShortest = weight;

                    secondCity = i;
                }
            }
        }

        int chosenCity;

        if(secondCity != -1)
        {
            chosenCity = secondCity;
        }
        else
        {
            chosenCity = bestCity;
        }

        if(chosenCity == -1)
        {
            break;
        }

        route[count] = chosenCity;

        visited[chosenCity] = 1;

        totalCost =
        totalCost +
        g.adjMatrix[current][chosenCity];

        current = chosenCity;
    }

    totalCost =
    totalCost +
    g.adjMatrix[current][0];

    end = clock();

    customTime =
    ((double)(end - start) * 1000)
    /
    CLOCKS_PER_SEC;

    cout << fixed << setprecision(6);

    cout << "\n===== Custom Algorithm =====\n";

    cout << "Second Shortest Path Strategy\n";

    cout << "\nRoute: ";

    for(int i = 0; i < g.vertices; i++)
    {
        cout
        << g.cityNames[route[i]]
        << " -> ";
    }

    cout << g.cityNames[0];

    cout << "\nCost: "
         << totalCost;

    cout << "\nExecution Time: "
         << customTime
         << " ms";

    cout << "\nComplexity: Approx O(n^2)\n";
}
void Algorithms::performanceReport()
{
    cout
    << "\n==============================================================";

    cout
    << "\n                    PERFORMANCE REPORT";

    cout
    << "\n==============================================================\n";

    cout
    << left
    << setw(25) << "Algorithm"
    << setw(20) << "Time(ms)"
    << setw(20) << "Complexity"
    << setw(20) << "Representation"
    << endl;

    cout
    << "--------------------------------------------------------------\n";

    cout
    << left
    << setw(25) << "Brute Force Static"
    << setw(20) << bruteForceTime
    << setw(20) << "O(n!)"
    << setw(20) << "Matrix"
    << endl;

    cout
    << left
    << setw(25) << "Brute Force Dynamic"
    << setw(20) << bruteForceDynamicTime
    << setw(20) << "O(n!)"
    << setw(20) << "Linked List"
    << endl;

    cout
    << left
    << setw(25) << "Greedy Static"
    << setw(20) << greedyMatrixTime
    << setw(20) << "O(n^2)"
    << setw(20) << "Matrix"
    << endl;

    cout
    << left
    << setw(25) << "Greedy Dynamic"
    << setw(20) << greedyListTime
    << setw(20) << "O(V + E)"
    << setw(20) << "Linked List"
    << endl;

    cout
    << left
    << setw(25) << "Custom Algorithm"
    << setw(20) << customTime
    << setw(20) << "Approx O(n^2)"
    << setw(20) << "Dynamic"
    << endl;

    cout
    << "\n==============================================================";

    cout
    << "\n                SPACE REQUIREMENT ANALYSIS";

    cout
    << "\n==============================================================\n";

    cout
    << left
    << setw(30) << "Algorithm"
    << setw(30) << "Space Complexity"
    << endl;

    cout
    << "--------------------------------------------------------------\n";

    cout
    << left
    << setw(30) << "Brute Force"
    << setw(30) << "O(n!)"
    << endl;

    cout
    << left
    << setw(30) << "Greedy Matrix"
    << setw(30) << "O(V^2)"
    << endl;

    cout
    << left
    << setw(30) << "Greedy Dynamic"
    << setw(30) << "O(V + E)"
    << endl;

    cout
    << left
    << setw(30) << "Custom Algorithm"
    << setw(30) << "O(V + E)"
    << endl;

    cout
    << "\nAdjacency Matrix Memory : Fixed Size Storage";

    cout
    << "\nLinked List Memory      : Depends on edges";

    cout
    << "\n\n==============================================================";

    cout
    << "\n             STATIC VS DYNAMIC REPRESENTATION";

    cout
    << "\n==============================================================\n";

    cout
    << left
    << setw(25) << "Feature"
    << setw(25) << "Static"
    << setw(25) << "Dynamic"
    << endl;

    cout
    << "--------------------------------------------------------------\n";

    cout
    << left
    << setw(25) << "Memory Usage"
    << setw(25) << "Higher"
    << setw(25) << "Lower"
    << endl;

    cout
    << left
    << setw(25) << "Access Speed"
    << setw(25) << "Faster"
    << setw(25) << "Moderate"
    << endl;

    cout
    << left
    << setw(25) << "Best For"
    << setw(25) << "Dense Graphs"
    << setw(25) << "Sparse Graphs"
    << endl;
}