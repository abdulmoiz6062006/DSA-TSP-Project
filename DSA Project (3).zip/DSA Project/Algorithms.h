#ifndef ALGORITHMS_H
#define ALGORITHMS_H

#include "Graph.h"

class Algorithms
{
public:

    static void bruteForceMatrix(Graph &g);

    static void bruteForceList(Graph &g);

    static void greedyMatrix(Graph &g);

    static void greedyList(Graph &g);

    static void customAlgorithm(Graph &g);

    static void performanceReport();
};

#endif