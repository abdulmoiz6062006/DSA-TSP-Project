#include <QApplication>
#include <QMainWindow>
#include <QPushButton>
#include <QTextEdit>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QWidget>
#include <QMessageBox>
#include <QFile>
#include <QTextStream>
#include <QString>
#include <QDebug>
#include <QFileDialog>
#include <QFont>
#include <QGraphicsView>
#include <QGraphicsScene>
#include <QGraphicsEllipseItem>
#include <QGraphicsLineItem>
#include <QGraphicsTextItem>
#include <QComboBox>
#include <cmath>

using namespace std;

// =====================================================
// GRAPH CLASS
// =====================================================
class Graph
{
public:
    struct Node
    {
        int city;
        int weight;
        Node* next;
    };

    int vertices;
    QString cityNames[20];
    int adjMatrix[20][20];
    Node* adjList[20];

    Graph()
    {
        vertices = 0;
        for(int i = 0; i < 20; i++)
        {
            adjList[i] = nullptr;
            for(int j = 0; j < 20; j++)
            {
                adjMatrix[i][j] = 0;
            }
        }
    }

    bool loadFromFile(const QString& filename)
    {
        QFile file(filename);
        if(!file.open(QIODevice::ReadOnly | QIODevice::Text))
        {
            qDebug() << "File Error:" << filename;
            return false;
        }

        QTextStream in(&file);
        in >> vertices;

        for(int i = 0; i < vertices; i++)
        {
            in >> cityNames[i];
        }

        for(int i = 0; i < vertices; i++)
        {
            for(int j = 0; j < vertices; j++)
            {
                in >> adjMatrix[i][j];
            }
        }

        for(int i = 0; i < vertices; i++)
        {
            while(adjList[i] != nullptr)
            {
                Node* temp = adjList[i];
                adjList[i] = adjList[i]->next;
                delete temp;
            }
            adjList[i] = nullptr;
        }

        for(int i = 0; i < vertices; i++)
        {
            for(int j = 0; j < vertices; j++)
            {
                if(adjMatrix[i][j] != 0)
                {
                    Node* newNode = new Node;
                    newNode->city = j;
                    newNode->weight = adjMatrix[i][j];
                    newNode->next = nullptr;

                    if(adjList[i] == nullptr)
                    {
                        adjList[i] = newNode;
                    }
                    else
                    {
                        Node* temp = adjList[i];
                        while(temp->next != nullptr)
                        {
                            temp = temp->next;
                        }
                        temp->next = newNode;
                    }
                }
            }
        }

        file.close();
        return true;
    }

    QString getMatrixString() const
    {
        QString str;
        str += "===== Adjacency Matrix =====\n\n";

        // Find the longest city name to dynamically set the column width
        int maxNameLen = 0;
        for (int i = 0; i < vertices; i++) {
            if (cityNames[i].length() > maxNameLen) {
                maxNameLen = cityNames[i].length();
            }
        }

        // Ensure there are always at least 2 spaces after the longest name
        int colWidth = maxNameLen + 2;

        str += QString("").leftJustified(colWidth, ' ');
        for(int i = 0; i < vertices; i++)
        {
            str += cityNames[i].leftJustified(colWidth, ' ');
        }
        str += "\n\n";

        for(int i = 0; i < vertices; i++)
        {
            str += cityNames[i].leftJustified(colWidth, ' ');
            for(int j = 0; j < vertices; j++)
            {
                str += QString::number(adjMatrix[i][j]).leftJustified(colWidth, ' ');
            }
            str += "\n";
        }
        return str;
    }

    QString getListString() const
    {
        QString str;
        str += "===== Adjacency Linked List =====\n\n";

        // Find the longest city name to establish a uniform grid
        int maxNameLen = 0;
        for (int i = 0; i < vertices; i++) {
            if (cityNames[i].length() > maxNameLen) {
                maxNameLen = cityNames[i].length();
            }
        }

        // Width for the left-hand root node (Name + " -> ")
        int headWidth = maxNameLen + 5;
        // Width for the list nodes "Name(Weight)  "
        int nodeWidth = maxNameLen + 6;

        for(int i = 0; i < vertices; i++)
        {
            QString headStr = cityNames[i] + " ->";
            str += headStr.leftJustified(headWidth, ' ');

            Node* temp = adjList[i];
            while(temp != nullptr)
            {
                QString nodeStr = cityNames[temp->city] + "(" + QString::number(temp->weight) + ")";
                str += nodeStr.leftJustified(nodeWidth, ' ');
                temp = temp->next;
            }
            str += "\n";
        }
        return str;
    }

    bool isDisconnected() const
    {
        for(int i = 0; i < vertices; i++)
        {
            bool connected = false;
            for(int j = 0; j < vertices; j++)
            {
                if(adjMatrix[i][j] != 0)
                {
                    connected = true;
                    break;
                }
            }
            if(!connected) return true;
        }
        return false;
    }
};

// =====================================================
// ALGORITHMS CLASS
// =====================================================
class Algorithms
{
public:
    static int minimumCost;
    static int bestPath[20];

    struct Result {
        int cost;
        QString route;
    };
    static Result lastResult;

    static void copyPath(int path[], int size)
    {
        for(int i = 0; i < size; i++)
        {
            bestPath[i] = path[i];
        }
    }

    static void bruteForceRecursive(Graph &g, int path[], int visited[], int level, int cost)
    {
        if(level == g.vertices)
        {
            if(g.adjMatrix[path[level - 1]][0] != 0)
            {
                cost += g.adjMatrix[path[level - 1]][0];
                if(cost < minimumCost)
                {
                    minimumCost = cost;
                    copyPath(path, g.vertices);
                }
            }
            return;
        }

        for(int i = 1; i < g.vertices; i++)
        {
            if(visited[i] == 0 && g.adjMatrix[path[level - 1]][i] != 0)
            {
                visited[i] = 1;
                path[level] = i;
                bruteForceRecursive(g, path, visited, level + 1, cost + g.adjMatrix[path[level - 1]][i]);
                visited[i] = 0;
            }
        }
    }

    static QString bruteForceMatrix(Graph &g)
    {
        int path[20] = {0};
        int visited[20] = {0};
        minimumCost = 99999;

        path[0] = 0;
        visited[0] = 1;

        bruteForceRecursive(g, path, visited, 1, 0);

        QString r = ""; // For table (Initials)
        QString output = "===== Brute Force Matrix =====\nRoute: "; // For standalone output (Full names)

        for(int i = 0; i < g.vertices; i++)
        {
            r += g.cityNames[bestPath[i]].left(1) + "-";
            output += g.cityNames[bestPath[i]] + " -> ";
        }
        r += g.cityNames[0].left(1);
        output += g.cityNames[0] + "\nCost: " + QString::number(minimumCost) + "\nComplexity: O(n!)\n";

        lastResult.cost = minimumCost;
        lastResult.route = r;

        return output;
    }

    static QString greedyMatrix(Graph &g)
    {
        int visited[20] = {0};
        int route[20] = {0};
        int current = 0;
        int totalCost = 0;

        visited[0] = 1;
        route[0] = 0;

        for(int count = 1; count < g.vertices; count++)
        {
            int min = 99999;
            int next = -1;

            for(int i = 0; i < g.vertices; i++)
            {
                if(visited[i] == 0 && g.adjMatrix[current][i] != 0)
                {
                    if(g.adjMatrix[current][i] < min)
                    {
                        min = g.adjMatrix[current][i];
                        next = i;
                    }
                }
            }

            if(next == -1) break;

            route[count] = next;
            visited[next] = 1;
            totalCost += min;
            current = next;
        }

        totalCost += g.adjMatrix[current][0];
        copyPath(route, g.vertices);

        QString r = ""; // For table (Initials)
        QString output = "===== Greedy Matrix =====\nRoute: "; // For standalone output (Full names)

        for(int i = 0; i < g.vertices; i++)
        {
            r += g.cityNames[route[i]].left(1) + "-";
            output += g.cityNames[route[i]] + " -> ";
        }
        r += g.cityNames[0].left(1);
        output += g.cityNames[0] + "\nCost: " + QString::number(totalCost) + "\nComplexity: O(n²)\n";

        lastResult.cost = totalCost;
        lastResult.route = r;

        return output;
    }

    static QString customAlgorithm(Graph &g)
    {
        int visited[20] = {0};

        int route[20] = {0};

        int current = 0;

        int totalCost = 0;

        visited[0] = 1;

        route[0] = 0;

        for(int count = 1;
             count < g.vertices;
             count++)
        {
            int shortest = 99999;

            int secondShortest = 99999;

            int bestCity = -1;

            int secondCity = -1;

            for(int i = 0;
                 i < g.vertices;
                 i++)
            {
                if(
                    visited[i] == 0 &&
                    g.adjMatrix[current][i] != 0
                    )
                {
                    int weight =
                        g.adjMatrix[current][i];

                    if(weight < shortest)
                    {
                        secondShortest = shortest;

                        secondCity = bestCity;

                        shortest = weight;

                        bestCity = i;
                    }
                    else if(weight < secondShortest)
                    {
                        secondShortest = weight;

                        secondCity = i;
                    }
                }
            }

            int chosenCity;

            if(secondCity != -1)
            {
                chosenCity = secondCity;
            }
            else
            {
                chosenCity = bestCity;
            }

            if(chosenCity == -1)
            {
                break;
            }

            route[count] = chosenCity;

            visited[chosenCity] = 1;

            totalCost =
                totalCost +
                g.adjMatrix[current][chosenCity];

            current = chosenCity;
        }

        totalCost =
            totalCost +
            g.adjMatrix[current][0];

        copyPath(route, g.vertices);

        QString r = "";

        QString output =
            "===== Custom Algorithm =====\n"
            "Second Shortest Path Strategy\n"
            "Route: ";

        for(int i = 0;
             i < g.vertices;
             i++)
        {
            r +=
                g.cityNames[route[i]].left(1)
                + "-";

            output +=
                g.cityNames[route[i]]
                + " -> ";
        }

        r +=
            g.cityNames[0].left(1);

        output +=
            g.cityNames[0]
            + "\nCost: "
            + QString::number(totalCost)
            + "\nComplexity: Approx O(n²)\n";

        lastResult.cost = totalCost;

        lastResult.route = r;

        return output;
    }
};

int Algorithms::minimumCost = 99999;
int Algorithms::bestPath[20] = {0};
Algorithms::Result Algorithms::lastResult = {0, ""};

// =====================================================
// MAIN WINDOW
// =====================================================
class MainWindow : public QMainWindow
{
public:
    Graph g;
    QTextEdit* textOutput;
    QGraphicsScene* scene;
    QGraphicsView* graphView;

    MainWindow()
    {
        setWindowTitle("TSP Visual Solver - Pro Edition");
        resize(1280, 850);

        this->setStyleSheet(
            "QMainWindow { background-color: #121212; }"

            /* Text Console Styling (Fixed White Text) */
            "QTextEdit {"
            "    background-color: #1e1e1e;"
            "    border: 1px solid #333333;"
            "    border-radius: 6px;"
            "    padding: 15px;"
            "    color: #ffffff;"
            "    font-size: 13px;"
            "}"

            /* 1. IMPORT BUTTON STYLING */
            "QPushButton#btnImport {"
            "    background-color: #1e3a8a;" /* Dark Blue */
            "    color: #ffffff;"
            "    border: 1px solid #172554;"
            "    border-radius: 6px;"
            "    padding: 10px 20px;"
            "    font-family: 'Segoe UI', Arial;"
            "    font-size: 14px;"
            "    font-weight: 600;"
            "    letter-spacing: 0.5px;"
            "}"
            "QPushButton#btnImport:hover {"
            "    background-color: #3b82f6;" /* Light Blue */
            "    border: 1px solid #93c5fd;"
            "}"
            "QPushButton#btnImport:pressed {"
            "    background-color: #1d4ed8;"
            "}"

            /* 2. COMBO BOXES / DROPDOWNS STYLING */
            "QComboBox {"
            "    background-color: #27ae60;" /* Green */
            "    color: #ffffff;"
            "    border: 1px solid #1e8449;"
            "    border-radius: 6px;"
            "    padding: 10px 15px;"
            "    font-family: 'Segoe UI', Arial;"
            "    font-size: 14px;"
            "    font-weight: 600;"
            "}"
            "QComboBox:hover {"
            "    background-color: #2ecc71;" /* Lighter Green on hover */
            "    border: 1px solid #27ae60;"
            "}"
            "QComboBox::drop-down {"
            "    border-left: 1px solid #1e8449;"
            "    width: 30px;"
            "}"

            /* 3. DROPDOWN OPTIONS LIST STYLING */
            "QComboBox QAbstractItemView {"
            "    background-color: #abebc6;" /* Light Green Options Box */
            "    color: #111111;"
            "    border: 1px solid #27ae60;"
            "    selection-background-color: #82e0aa;"
            "    selection-color: #000000;"
            "}"
            );

        QWidget* centralWidget = new QWidget;
        setCentralWidget(centralWidget);

        QVBoxLayout* mainLayout = new QVBoxLayout;

        // ---------------------------------------------------------
        // TOP LAYOUT: Button and Dropdowns
        // ---------------------------------------------------------
        QHBoxLayout* topControlBar = new QHBoxLayout;
        topControlBar->setSpacing(20);
        topControlBar->setContentsMargins(10, 10, 10, 10);

        QPushButton* btnLoad = new QPushButton("Import File");
        btnLoad->setObjectName("btnImport");
        btnLoad->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed);

        QComboBox* comboDisplay = new QComboBox();
        comboDisplay->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed);
        comboDisplay->addItem("Display (Select...)");
        comboDisplay->addItem("Adjacency Matrix");
        comboDisplay->addItem("Adjacency List");

        QComboBox* comboAlgorithm = new QComboBox();
        comboAlgorithm->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed);
        comboAlgorithm->addItem("Algorithms (Select...)");
        comboAlgorithm->addItem("Brute Force");
        comboAlgorithm->addItem("Greedy");
        comboAlgorithm->addItem("Custom");
        comboAlgorithm->addItem("Run All Algorithms");

        topControlBar->addWidget(btnLoad, 1);
        topControlBar->addWidget(comboDisplay, 1);
        topControlBar->addWidget(comboAlgorithm, 1);

        // ---------------------------------------------------------
        // MIDDLE LAYOUT: Graph Area
        // ---------------------------------------------------------
        scene = new QGraphicsScene(this);
        graphView = new QGraphicsView(scene);
        graphView->setRenderHint(QPainter::Antialiasing);
        graphView->setStyleSheet("background-color: #1a1a1a; border-radius: 6px; border: 1px solid #333333;");

        // ---------------------------------------------------------
        // BOTTOM LAYOUT: Text Console
        // ---------------------------------------------------------
        textOutput = new QTextEdit;
        textOutput->setReadOnly(true);
        textOutput->setFont(QFont("Consolas", 11));
        textOutput->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Preferred);
        textOutput->setMinimumHeight(200);

        mainLayout->addLayout(topControlBar, 0);
        mainLayout->addWidget(graphView, 4);
        mainLayout->addWidget(textOutput, 1);

        centralWidget->setLayout(mainLayout);

        // ================= SIGNALS =================
        connect(btnLoad, &QPushButton::clicked, [=]()
                {
                    QString filename = QFileDialog::getOpenFileName(this, "Select Graph Data File", "", "Text Files (*.txt);;All Files (*)");
                    if (filename.isEmpty()) return;

                    if(g.loadFromFile(filename))
                    {
                        appendOutput("Graph Loaded Successfully from: " + filename);
                        renderGraph(false);
                        if(g.isDisconnected()) QMessageBox::warning(this, "Warning", "Graph is disconnected! Routing algorithms may fail.");
                    }
                    else QMessageBox::critical(this, "Error", "Could not load the selected file.");
                });

        connect(comboDisplay, QOverload<int>::of(&QComboBox::activated), [=](int index) {
            if (index == 1) {
                appendOutput(g.getMatrixString());
            } else if (index == 2) {
                appendOutput(g.getListString());
            }
            comboDisplay->setCurrentIndex(0);
        });

        connect(comboAlgorithm, QOverload<int>::of(&QComboBox::activated), [=](int index) {
            if (g.vertices == 0 && index != 0) {
                appendOutput("Please import a graph file first.");
                comboAlgorithm->setCurrentIndex(0);
                return;
            }

            if (index == 1) {
                appendOutput(Algorithms::bruteForceMatrix(g));
                renderGraph(true);
            }
            else if (index == 2) {
                appendOutput(Algorithms::greedyMatrix(g));
                renderGraph(true);
            }
            else if (index == 3) {
                appendOutput(Algorithms::customAlgorithm(g));
                renderGraph(true);
            }
            else if (index == 4) {
                Algorithms::bruteForceMatrix(g);
                Algorithms::Result bruteRes = Algorithms::lastResult;

                Algorithms::greedyMatrix(g);
                Algorithms::Result greedyRes = Algorithms::lastResult;

                Algorithms::customAlgorithm(g);
                Algorithms::Result customRes = Algorithms::lastResult;

                renderGraph(true);

                // Increased column width for breathing room
                int col = 28;
                // Extended lines to cover the wider columns exactly
                QString lineEq = "============================================================================================================";
                QString lineDash = "------------------------------------------------------------------------------------------------------------";

                QString tableOut = lineEq + "\n";
                tableOut += QString("METRIC").leftJustified(15, ' ') + " | " +
                            QString("BRUTE FORCE").leftJustified(col, ' ') + " | " +
                            QString("GREEDY").leftJustified(col, ' ') + " | " +
                            QString("CUSTOM").leftJustified(col, ' ') + "\n";
                tableOut += lineDash + "\n";

                tableOut += QString("Total Cost").leftJustified(15, ' ') + " | " +
                            QString::number(bruteRes.cost).leftJustified(col, ' ') + " | " +
                            QString::number(greedyRes.cost).leftJustified(col, ' ') + " | " +
                            QString::number(customRes.cost).leftJustified(col, ' ') + "\n";

                tableOut += QString("Path Route").leftJustified(15, ' ') + " | " +
                            bruteRes.route.leftJustified(col, ' ') + " | " +
                            greedyRes.route.leftJustified(col, ' ') + " | " +
                            customRes.route.leftJustified(col, ' ') + "\n";

                tableOut += lineEq + "\n";
                appendOutput("RUNNING ALL ALGORITHMS...\n\n" + tableOut);
            }
            comboAlgorithm->setCurrentIndex(0);
        });

        appendOutput("Welcome to the TSP Visual Solver!\nPlease click 'Import File' to select your data.");
    }

    void renderGraph(bool highlightRoute)
    {
        scene->clear();
        if (g.vertices == 0) return;

        int radius = 200;
        QPointF center(600, 250);
        QPointF pos[20];

        for (int i = 0; i < g.vertices; i++) {
            double angle = 2.0 * M_PI * i / g.vertices;
            pos[i] = center + QPointF(radius * std::cos(angle), radius * std::sin(angle));
        }

        QPen baseEdgePen(QColor(60, 60, 60), 1.5, Qt::SolidLine);
        for (int i = 0; i < g.vertices; i++) {
            for (int j = i + 1; j < g.vertices; j++) {
                if (g.adjMatrix[i][j] != 0 || g.adjMatrix[j][i] != 0) {
                    scene->addLine(pos[i].x(), pos[i].y(), pos[j].x(), pos[j].y(), baseEdgePen);
                }
            }
        }

        if (highlightRoute) {
            QPen routePen(QColor(86, 156, 214), 3.5, Qt::SolidLine);
            for (int i = 0; i < g.vertices; i++) {
                int currentCity = Algorithms::bestPath[i];
                int nextCity = (i == g.vertices - 1) ? Algorithms::bestPath[0] : Algorithms::bestPath[i+1];

                scene->addLine(pos[currentCity].x(), pos[currentCity].y(), pos[nextCity].x(), pos[nextCity].y(), routePen);

                int weight = g.adjMatrix[currentCity][nextCity];
                if (weight == 0) weight = g.adjMatrix[nextCity][currentCity];

                QPointF midPoint = (pos[currentCity] + pos[nextCity]) / 2.0;

                QGraphicsTextItem* weightText = scene->addText(QString::number(weight), QFont("Segoe UI", 11, QFont::Bold));
                weightText->setDefaultTextColor(QColor(215, 186, 125));

                qreal textX = midPoint.x() - weightText->boundingRect().width() / 2;
                qreal textY = midPoint.y() - weightText->boundingRect().height() / 2;

                auto textBg = scene->addRect(textX, textY + 2, weightText->boundingRect().width(), weightText->boundingRect().height() - 4, Qt::NoPen, QBrush(QColor(30, 30, 30, 200)));
                weightText->setPos(textX, textY);
                weightText->setZValue(1);
            }
        }

        int nodeRadius = 22;
        QBrush nodeBrush(QColor(30, 30, 30));
        QPen nodePen(QColor(86, 156, 214), 2.5);

        for (int i = 0; i < g.vertices; i++) {
            scene->addEllipse(pos[i].x() - nodeRadius, pos[i].y() - nodeRadius,
                              nodeRadius * 2, nodeRadius * 2, nodePen, nodeBrush);

            QGraphicsTextItem* text = scene->addText(g.cityNames[i], QFont("Segoe UI", 10, QFont::Bold));
            text->setDefaultTextColor(QColor(220, 220, 220));

            qreal textX = pos[i].x() - text->boundingRect().width() / 2;
            qreal textY = pos[i].y() - text->boundingRect().height() / 2;
            text->setPos(textX, textY);
            text->setZValue(2);
        }
    }

    void appendOutput(const QString& text)
    {
        // Enforce bright white for the main text block
        textOutput->setTextColor(QColor("#ffffff"));
        textOutput->append(text);

        // Enforce dark grey strictly for the separator so it doesn't bleed
        textOutput->setTextColor(QColor("#444444"));
        textOutput->append("------------------------------------------------------------------------------------------------------------");

        QTextCursor cursor = textOutput->textCursor();
        cursor.movePosition(QTextCursor::End);
        textOutput->setTextCursor(cursor);
    }
};

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    MainWindow window;
    window.show();
    return app.exec();
}